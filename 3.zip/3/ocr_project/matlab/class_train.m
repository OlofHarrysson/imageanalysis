function [classification_data] = class_train(X,Y)


end

